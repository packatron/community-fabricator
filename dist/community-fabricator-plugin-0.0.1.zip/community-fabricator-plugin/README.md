# community-fabricator

docker-compose run --rm composer install

